using Avalonia.Controls;

namespace uchat_client.Views;

public partial class ChatView : UserControl
{
    public ChatView()
    {
        InitializeComponent();
    }
}